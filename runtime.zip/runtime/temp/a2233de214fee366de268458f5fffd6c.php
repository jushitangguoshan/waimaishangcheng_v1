<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:74:"E:\takeout.com\public/../application/admin\view\admin\admin_role_list.html";i:1554715329;}*/ ?>
<!DOCTYPE html>
<html class="x-admin-sm">
  
  <head>
    <meta charset="UTF-8">
    <title>欢迎页面-X-admin2.1</title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width,user-scalable=yes, minimum-scale=0.4, initial-scale=0.8,target-densitydpi=low-dpi" />
    <link rel="stylesheet" href="/static/admin/css/font.css">
    <link rel="stylesheet" href="/static/admin/css/xadmin.css">
    <script type="text/javascript" src="https://cdn.bootcss.com/jquery/3.2.1/jquery.min.js"></script>
    <script type="text/javascript" src="/static/admin/lib/layui/layui.js" charset="utf-8"></script>
    <script type="text/javascript" src="/static/admin/js/xadmin.js"></script>
    <script type="text/javascript" src="/static/admin/js/cookie.js"></script>

  </head>
  <body>
    <div class="x-nav">
      <span class="layui-breadcrumb">
        <a href="">首页</a>
        <a href="">角色列表</a>
        <a>
          <cite>列表信息</cite></a>
      </span>
      <a class="layui-btn layui-btn-small" style="line-height:1.6em;margin-top:3px;float:right" href="javascript:location.replace(location.href);" title="刷新">
        <i class="layui-icon" style="line-height:30px">ဂ</i></a>
    </div>
    <div class="layui-card">
      <div class="layui-card-body">
        <table class="layui-table" id="role_table" lay-filter="role_table"> </table>
      </div>
    </div>

    <script>
      layui.use(['laydate','form','table'], function() {
          var $ = layui.jquery,
              table = layui.table,
              form = layui.form;
          table.render({
              elem:'#role_table',
              url:'<?php echo url('admin/admin/getAdminRoleList'); ?>',
              cols:[[//表头
                  {field: 'id', title:"ID", width:150, sort:true, align:'center'}
                  ,{field: 'role_name', title:"角色名称", width:150, align:'center'}
                  ,{field: 'role_rules', title:'角色规则', width:308, align:'center'}
                  ,{field: 'descript', title:'角色描述', width:350, align:'center'}
                  ,{field: 'status', title: '状态', width: 150, templet: "#statusTpl"}
              ]]
          })
          //执行一个laydate实例
      });
    </script>
  </body>
  <script type="text/html" id="statusTpl">
    <input type="checkbox" name="switch" lay-text="开启" disabled checked  lay-filter="status_switch" lay-skin="switch"
    <!--{{# if(d.status == 1){ }}-->
    <!--<input type="checkbox" name="switch" lay-text="开启|停用" checked  lay-filter="status_switch" lay-skin="switch">-->
    <!--&lt;!&ndash;<span class="layui-btn layui-btn-normal layui-btn-xs admin_status">启用</span>&ndash;&gt;-->
    <!--{{# }else{ }}-->
    <!--<input type="checkbox" name="switch" lay-text="开启|停用"  lay-filter="status_switch" lay-skin="switch">-->
    <!--&lt;!&ndash;<span class="layui-btn layui-btn-disabled layui-btn-xs admin_status">已停用</span>&ndash;&gt;-->
    <!--{{#  } }}-->
  </script>
</html>