<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:65:"E:\takeout.com\public/../application/admin\view\home\welcome.html";i:1554715329;}*/ ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>Insert title here</title>
    <link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css">
</head>
<body width="100%">
<center>

    <br>
    <br>
    <br>
    <br>
    <h3>系统信息</h3>
    <table width="70%" class="table  table-bordered table-hover">
        <tr>
            <th>操作系统</th>
            <td>Linux</td>
        </tr>
        <tr>
            <th>Nginx版本</th>
            <td>Nginx 1.4.6</td>
        </tr>
        <tr>
            <th>PHP版本</th>
            <td>5.5.38</td>
        </tr>
        <tr>
            <th>运行方式</th>
            <td>fpm-fcgi</td>
        </tr>
    </table>
</center>

<script src="/static/admin/js/jquery-1.8.3.js"></script>
</body>
</html>