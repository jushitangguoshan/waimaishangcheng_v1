<?php
/**
 * Created by 巨石糖果山.
 * User: 1034610091@qq.com
 * Date:2019/4/3 0003 / 上午 10:05
 */
// 应用行为扩展定义文件
return [
    'isAjax'        =>["app\admin\behavior\checkIsAjax"],
    'isPost'        =>["app\admin\behavior\checkDataIsPost"],
];
