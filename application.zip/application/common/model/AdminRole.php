<?php
/**
 * Created by 巨石糖果山.
 * User: 1034610091@qq.com
 * Date:2019/4/6 0006 / 上午 8:59
 */

namespace app\common\model;


use think\Model;


class AdminRole extends Model
{
    // 创建时间字段
    protected $createTime = 'create_time';
}