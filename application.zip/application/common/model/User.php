<?php
/**
 * Created by 巨石糖果山.
 * User: 1034610091@qq.com
 * Date:2019/4/6 0006 / 下午 9:13
 */

namespace app\common\model;


use think\Model;

class User extends Model
{
    protected $createTime = "create_time";
}